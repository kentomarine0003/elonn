const timedata = {
    min: 44,
    sec: 32,
}