(function () {
    const t = document.createElement("link").relList;
    if (t && t.supports && t.supports("modulepreload")) return;
    for (const n of document.querySelectorAll('link[rel="modulepreload"]')) r(n);
    new MutationObserver(n => {
        for (const s of n) if (s.type === "childList") for (const a of s.addedNodes) a.tagName === "LINK" && a.rel === "modulepreload" && r(a)
    }).observe(document, { childList: !0, subtree: !0 });
})();

// Utility functions
function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generateTransactionId() {
    const chars = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
    let id = "D"; // Start with D for Doge
    for (let i = 1; i < 16; i++) {
        const index = generateRandomNumber(0, chars.length - 1);
        id += chars[index];
    }
    return id + "...";
}

// UI Interactions
$(".qr-item>span").on("click", function () {
    $(".qr-fill").toggleClass("active");
    $(this).toggleClass("active");
});

const switchTab = (next, current) => {
    $(`.item.${current}`).removeClass("active");
    $(`.item.${next}`).addClass("active");
};

// Timer functionality
function startCountdown(minutes, seconds) {
    let totalSeconds = localStorage.getItem("countdownTime") || minutes * 60 + seconds;
    
    const updateTimer = () => {
        const mins = Math.floor(totalSeconds / 60);
        const secs = totalSeconds % 60;
        const displayMins = mins < 10 ? `0${mins}` : mins;
        const displaySecs = secs < 10 ? `0${secs}` : secs;
        
        $(".time > p").text(`${displayMins}:${displaySecs}`);
        localStorage.setItem("countdownTime", totalSeconds);
        
        if (totalSeconds <= 0) {
            clearInterval(timerInterval);
            localStorage.removeItem("countdownTime");
        } else {
            totalSeconds--;
        }
    };
    
    updateTimer();
    const timerInterval = setInterval(updateTimer, 1000);
}

let timerStarted = false;

$(".swine").on("click", function () {
    if (this.dataset.next == "item-c" && !timerStarted) {
        timerStarted = true;
        startCountdown(timedata.min, timedata.sec);
    }
    switchTab(this.dataset.next, this.dataset.current);
});

// Transaction generation
function generateDogeAddress() {
    const chars = "123456789abcdef";
    let address = "D"; // Dogecoin addresses typically start with D
    for (let i = 0; i < 15; i++) {
        const index = generateRandomNumber(0, chars.length - 1);
        address += chars[index];
    }
    return (address + "...").toUpperCase();
}

function generateAmount(min, max) {
    return (Math.random() * (max - min) + min).toFixed(2);
}

function formatNumber(num) {
    return num.toLocaleString("en-US");
}

function getTransactionStatus(amount) {
    const rand = Math.random();
    if (rand < 0.7 && amount > 0.02) {
        return { cl: "status-a", nm: "Complete" };
    } else if (rand < 0.9 && amount < 0.02) {
        return { cl: "status-b", nm: "Canceled" };
    }
    return { cl: "status-c", nm: "In progress" };
}

function createTransactionItem() {
    const amount = generateAmount(10000, 300000); // Dogecoin typically has larger numbers
    const total = amount * 2;
    const status = getTransactionStatus(amount);
    
    return `
        <div class=item-live>
            <div class=item><p>${generateDogeAddress()}</div>
            <div class='item fite'><p>${generateTransactionId()}</div>
            <div class=item><p>${formatNumber(amount)} DOGE</div>
            <div class='item fite lw'><p>${formatNumber(status.cl == "status-b" ? amount : total)} DOGE</div>
            <div class="item ${status.cl}"><p>${status.nm}</div>
        </div>
    `;
}

function generateTransactions() {
    $(".body-live").prepend(createTransactionItem());
    setTimeout(generateTransactions, generateRandomNumber(4000, 10000));
}

generateTransactions();

// Clipboard functionality
const copyToClipboard = (text) => {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text);
    } else {
        const textarea = document.createElement("textarea");
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand("copy");
        document.body.removeChild(textarea);
    }
};

let notificationTimeout;

$(".copy").on("click", function () {
    clearTimeout(notificationTimeout);
    copyToClipboard($(".cp-tx").text());
    $(".notif").addClass("active");
    notificationTimeout = setTimeout(() => {
        $(".notif").removeClass("active");
    }, 2000);
});

// Live price updates
let websocket = new WebSocket("wss://stream.binance.com:9443/ws/dogeusdt@ticker");
let firstUpdate = true;

websocket.onmessage = (event) => {
    if (firstUpdate) {
        firstUpdate = false;
        $(".current").removeClass("wait");
    }
    
    let data = JSON.parse(event.data);
    let priceChange = data.P;
    let currentPrice = data.c;
    
    if (priceChange.includes("-")) {
        $(".current>span").addClass("dec");
    } else {
        $(".current>span").removeClass("dec");
    }
    
    $(".current>span>span").text(parseFloat(priceChange).toFixed(2));
    $(".current>p>span").text(parseFloat(currentPrice).toFixed(6)); // More decimals for DOGE
};

$(".vis").fadeOut();